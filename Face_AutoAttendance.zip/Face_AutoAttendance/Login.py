from tkinter import *
import tkinter as tk
from tkinter import font as tkFont
from tkinter.ttk import *
import os
from PIL import Image, ImageTk
import os.path
import sqlite3
from tkinter import messagebox



def login2():
    db=sqlite3.connect('login2.sqlite')
    db.execute('CREATE TABLE IF NOT EXISTS login2(username TEXT, password TEXT)')
    # db.execute("INSERT INTO login2(username, password) VALUES('admin', 'admin')")
    db.execute("INSERT INTO login2(username, password) VALUES('admin', 'pass')")
    cursor=db.cursor()
    cursor.execute("SELECT * FROM login2 where username=? AND password=?",(lid.get(), lpass.get()))
    row=cursor.fetchone()
    if row:
        messagebox.showinfo('info', 'login success')
    else:
        messagebox.showinfo('info', 'login failed')


# creates a Tk() object
master = Tk()


# sets the geometry of main
# root window
master.geometry("752x500")
master.title("Admin Login")


bg = PhotoImage(file = "C:/Users/square/Desktop/Projects2/Attendance_Systems/GUI/login.jpg")

canvas1 = Canvas( master, width = 400,
                  height = 400)

canvas1.pack(fill = "both", expand = True)

canvas1.create_image( 0, 0, image = bg,
                      anchor = "nw")

helv36 = tkFont.Font(family='Times New Roman', size=10, weight='bold')
lb0 =tk.Label(master,text="Enter ID :",background="deepskyblue",foreground="navyblue",font="lucida 10 bold",width=9,height=2)

label0_canvas=canvas1.create_window(465, 100,
                                    anchor = "nw",
                                    window = lb0)

lb1 =tk.Label(master,text="Enter Password :",background="deepskyblue",foreground="navyblue",font="lucida 10 bold",width=15,height=2)

label1_canvas=canvas1.create_window(440, 200,
                                    anchor = "nw",
                                    window = lb1)

large_font = ('Verdana',20)
lid =tk.StringVar()
e1 =tk.Entry(master,textvariable=lid,width=12,font=large_font)
entry1_canvas=canvas1.create_window(401, 150,
                                    anchor = "nw",
                                    window = e1)
lpass=tk.StringVar()
e2=tk.Entry(master,textvariable=lpass,width=12,font=large_font, show = '*')
entry2_canvas=canvas1.create_window(401, 250,
                                    anchor = "nw",
                                    window = e2)

btn = tk.Button(master,
                text ="LOGIN",
                command = login2,font="lucida 12 bold",bg="black",activebackground='gold',fg="white", height = 2, width = 12)
button1_canvas = canvas1.create_window( 430, 320,
                                        anchor = "nw",
                                        window = btn)


master.mainloop()


